# 🕌 تطبيق مواقيت الصلاة | Prayer Times App

تطبيق بسيط ومنظم لعرض وإدارة مواقيت الصلاة اليومية.

---

## 📢 تواصل معنا (الدعم الفني)
للحصول على آخر التحديثات أو للإبلاغ عن مشكلة، يمكنك الانضمام لمجموعتنا الرسمية على تيليجرام:

[![Telegram Group](https://img.shields.io/badge/Telegram-Group-blue?style=for-the-badge&logo=telegram&logoColor=white)](https://t.me/+GYhTcjbn_NUyNTA0)

---

## 🚀 المميزات
* عرض مواقيت الصلاة بشكل يومي.
* واجهة مستخدم متجاوبة مع جميع الشاشات.
* إمكانية تعديل الأوقات يدوياً.

## 🛠️ المتطلبات
كل ما تحتاجه هو متصفح ويب حديث (Chrome, Firefox, Edge).

## 👤 المطور
**Sameh Elnady** - [@samehelnady](https://github.com/samehelnady)
